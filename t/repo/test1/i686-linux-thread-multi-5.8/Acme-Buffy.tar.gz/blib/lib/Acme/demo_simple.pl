#!/usr/bin/perl

use Acme::Buffy;

print "Hello world\n"
	for(1..5);
